this is a file where we test the different encodings of the assets controller
this is the gzipped version.
