This is a test gzipped asset.
